package com.wangtry.webserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnerWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
